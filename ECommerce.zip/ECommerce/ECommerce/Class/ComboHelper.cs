﻿using ECommerce.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ECommerce.Class
{
    public class ComboHelper : IDisposable
    {
        private static Context db = new Context();

        public static List<Category> GetCategories()
        {
            var category = db.Categories.ToList();
            category.Add(new Category
            {
                CategoryId = 0,
                Name = "[ Selecione uma Categoria ]"
            });

            return category = category.OrderBy(o => o.Name).ToList();

        }

        public static List<Position> GetPositions()
        {
            var position = db.Positions.ToList();
            position.Add(new Position
            {
                PositionId = 0,
                Name = "[ Selecione um Papel ]"
            });

            return position = position.OrderBy(o => o.Name).ToList();

        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}