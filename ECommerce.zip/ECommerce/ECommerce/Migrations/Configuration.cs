namespace ECommerce.Migrations
{
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<ECommerce.Models.Context>
    {
        public Configuration()
        {
            //Para criar Migration
            //Enable-Migrations -ContextTypeName Context -EnableAutomaticMigrations -Force
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true; // Migration
            ContextKey = "ECommerce.Models.Context";
        }

        protected override void Seed(ECommerce.Models.Context context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
        }
    }
}
