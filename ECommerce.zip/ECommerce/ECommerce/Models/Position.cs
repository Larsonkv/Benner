﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerce.Models
{
    public class Position
    {
        [Key]
        [Display(Name = "Id")]
        public int PositionId { get; set; }

        [Required(ErrorMessage = "O campo Nome não pode ser vazio!")]
        [MaxLength(50, ErrorMessage = "O campo Nome não pode ter mais de 50 caracteres")]
        [Display(Name = "Nome")]
        [Index("Category_Name_Index", IsUnique = true)]
        public string Name { get; set; }

        public virtual ICollection<User> Users { get; set; }
    }
}