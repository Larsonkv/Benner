﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerce.Models
{
    public class Category
    {
        [Key]
        [Display(Name = "Id")]
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "O campo Nome não pode ser vazio!")]
        [MaxLength(50, ErrorMessage = "O campo Nome não pode ter mais de 50 caracteres")]
        [Display(Name = "Nome")]
        [Index("Category_Name_Index", IsUnique = true)]
        public string Name { get; set; }

        public virtual ICollection<Product> Products { get; set; }

    }
}