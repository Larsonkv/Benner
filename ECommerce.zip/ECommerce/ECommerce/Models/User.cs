﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web;

namespace ECommerce.Models
{
    public class User
    {
        [Key]
        [Display(Name = "Id")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "O campo E-mail não pode ser vazio!")]
        [Display(Name = "E-mail")]
        [DataType(DataType.EmailAddress)]
        [MaxLength(250, ErrorMessage = "O campo E-mail não pode ter mais de 250 caracteres")]
        [Index("User_UserName_Index", IsUnique = true)]
        public String UserName { get; set; }

        [Required(ErrorMessage = "O campo Nome não pode ser vazio!")]
        [Display(Name = "Nome")]
        [MaxLength(50, ErrorMessage = "O campo Nome não pode ter mais de 50 caracteres")]
        public String FirstName { get; set; }

        [Required(ErrorMessage = "O campo Sobrenome não pode ser vazio!")]
        [Display(Name = "Sobrenome")]
        [MaxLength(50, ErrorMessage = "O campo Sobrenome não pode ter mais de 50 caracteres")]
        public String LastName { get; set; }

        [Display(Name = "Usuário")]
        public String FullName { get { return string.Format("{0} {1}", FirstName, LastName); } }

        [Required(ErrorMessage = "O campo Telefone não pode ser vazio!")]
        [MaxLength(50, ErrorMessage = "O campo Telefone não pode ter mais de 50 caracteres")]
        [Display(Name = "Telefone")]
        [DataType(DataType.PhoneNumber)]
        public string Phone { get; set; }


        [Required(ErrorMessage = "O campo Endereço não pode ser vazio!")]
        [MaxLength(50, ErrorMessage = "O campo Endereço não pode ter mais de 50 caracteres")]
        [Display(Name = "Endereço")]
        public string Address { get; set; }

        [Display(Name = "Imagem")]
        [DataType(DataType.ImageUrl)]
        public string Image { get; set; }

        [NotMapped]
        public HttpPostedFileBase ImageUser { get; set; }

        [Required(ErrorMessage = "O campo Papel não pode ser vazio!")]
        [Display(Name = "Papel")]
        [Range(1, double.MaxValue, ErrorMessage = "Selecione um Papel!")]
        public int PositionId { get; set; }

        [Display(Name = "Papel")]
        public virtual Position Positions { get; set; }
    }
}