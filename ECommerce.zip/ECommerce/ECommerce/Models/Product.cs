﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web;

namespace ECommerce.Models
{
    public class Product
    {
        [Key]
        [Display(Name = "Id")]
        public int ProductId { get; set; }

        [Required(ErrorMessage = "O campo Nome não pode ser vazio!" )]
        [Display(Name = "Nome")]
        [MaxLength(50, ErrorMessage = "O campo Nome não pode ter mais de 50 caracteres")]
        [Index("Product_Name_Index", IsUnique = true)]
        public String Name { get; set; }

        [Required(ErrorMessage = "O campo Quantidade não pode ser vazio!")]
        [Display(Name = "Quantidade")]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "O campo Categoria não pode ser vazio!")]
        [Display(Name = "Categoria")]
        [Range(1, double.MaxValue, ErrorMessage = "Selecione uma Categoria!" )]
        public int CategoryId { get; set; }

        [Display(Name = "Categoria")]
        public virtual Category Category { get; set; }

        [Display(Name = "Imagem")]
        [DataType(DataType.ImageUrl)]
        public string Image { get; set; }
        
        [NotMapped]
        public HttpPostedFileBase ImageProduct { get; set; }

        [Required(ErrorMessage = "O campo Custo não pode ser vazio!")]
        [Display(Name = "Custo R$")]
        public float Cost { get; set; }

        [Required(ErrorMessage = "O campo Preço não pode ser vazio!")]
        [Display(Name = "Preço R$")]
        public float Price { get; set; }
    }
}